import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../../models/user';
import { Observable } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({ 
    'Content-Type': 'application/json',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwibmF0aW9uYWxJZCI6IjU1NSIsInJvbGUiOiJBRE1JTiIsImlzT3duZXIiOnRydWUsImV4cCI6MTU3NzE1MTY0MywiaWF0IjoxNTcxOTY3NjQzfQ.wcYS6Bu2BAPSrhbJqog0GPvRGx1ZBAEAyGviz62FpNk'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UserService {
  //usersUrlOld: string = 'https://jsonplaceholder.typicode.com/todos';
  //usersLimit: string = '?_limit=5';
  usersUrl: string = 'http://localhost:3000/api/user';
  userQuery: string = '?q=';

  constructor(private http: HttpClient) { }

  //returns an observable
  getUsers(filterText: string): Observable<User[]> {
    const query = (filterText === '')?'':`${this.userQuery}${filterText}`;
    return this.http.get<User[]>(`${this.usersUrl}${query}`);
    /*  return [{id: 1, first: 'First' , completed:true}, {id: 2, first: 'Second', completed:false},
    {id: 3, first: 'Third' , completed:true}]; */
  }

  getUser(id:number): Observable<User>{
    return this.http.get<User>(`${this.usersUrl}/${id}`, httpOptions);
  }

  addUser(user: User): Observable<User> {
    return this.http.post<User>(this.usersUrl, user, httpOptions);
  }

  editUser(user: User): Observable<any> {
    if(user.password !== undefined && user.password.trim() == ''){
      user.password = undefined;
     }
    
    //console.log(`onSubmit after ${user.password}`);
    const url = `${this.usersUrl}/${user.id}`;
    return this.http.put(url, user, httpOptions);
  }

  /*deleteUser(user: User): Observable<User> {
    const url = `${this.usersUrl}/${user.id}`;
    return this.http.delete<User>(url, httpOptions);
  }*/

  
}
